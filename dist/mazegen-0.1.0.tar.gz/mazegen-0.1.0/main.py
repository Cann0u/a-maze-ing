def main():
    print("Hello from a-maze-ing!")


if __name__ == "__main__":
    main()

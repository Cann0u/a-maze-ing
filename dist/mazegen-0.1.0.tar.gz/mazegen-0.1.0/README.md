*This project has been created as part of the 42 curriculum by thsykas rdedack*

#DESCRIPTION
A-Maze-ing est un projet de programmation en Python dont l'objectif est de concevoir un générateur de labyrinthes capable de créer des structures complexes, aléatoires et potentiellement "parfaites" (ne possédant qu'un chemin unique entre l'entrée et la sortie).

